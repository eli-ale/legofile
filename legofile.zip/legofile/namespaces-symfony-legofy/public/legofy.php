<?php


require_once "../vendor/autoload.php";

use RicardoFiorani\Legofy\Legofy as Lego;

$imagen = $_FILES['foto'];

// The multiplier for the amount of legos on your image, or "legolution" :)
$resolutionMultiplier = 5;

// When set to true it will only use lego colors that exists in real world.
$useLegoPalette = false;
try {
    $legofy = new Lego();
} catch (Exception $e){
    echo $e->getMessage(); die;
}

// $source can be any acceptable parameter for intervention/image
// Please see http://image.intervention.io/api/make
$source = $imagen['tmp_name'];
/**
 *@var Intervention\Image\Image
 */
$output = $legofy->convertToLego($source, $resolutionMultiplier, $useLegoPalette);

// Please see http://image.intervention.io/use/basics and http://image.intervention.io/use/http
echo $output->response();